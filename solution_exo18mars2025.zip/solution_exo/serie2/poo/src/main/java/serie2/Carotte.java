package serie2;

public class Carotte {
    public static void allo(){
        System.out.println("Je suis une carotte qui provient de serie 2");
    }
}
