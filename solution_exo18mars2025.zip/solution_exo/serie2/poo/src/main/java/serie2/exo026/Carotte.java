package serie2.exo026;
public class Carotte {
    public static void allo(){
        System.out.println("Je suis une carotte qui provient du exo026");
    }
}
