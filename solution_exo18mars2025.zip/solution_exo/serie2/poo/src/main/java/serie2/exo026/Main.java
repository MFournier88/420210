package poo.src.main.java.serie2.exo026;
import poo.src.main.java.aAsperge;
public class Main {
    public static void main(String[] args) {
        System.out.println("Hello world!");
        aAsperge legume = new aAsperge();
        legume.
    }
}