package poo.src.main.java;
import poo.src.main.java.serie2.Carotte;

public class Main {
    public static void main(String[] args) {
        Carotte.allo();
        aAsperge legume = new aAsperge();
        legume.
}
