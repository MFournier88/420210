package poo.src.main.java;
public class aAsperge {
    public String gout = "Miam!";
    protected String couleur = "Vert";
    private String cout = "5$";
}
