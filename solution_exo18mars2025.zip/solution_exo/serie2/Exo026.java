public class Exo026 {
    public static void main(String[] args) {
        
    }
}

class Animal{
    protected String nom;
    protected int age;
    protected String son;

    public Animal(String nom, int age, String son){

    }

    public void setNom(String nom){
        this.nom = nom;
    }
    public void setAge(int age){
        this.age = age;
    }
    public void setSon(String son){
        this.son = son;
    }

    public String getNom(){
        return this.nom;
    }
    public int getAge(){
        return this.age;
    }
    public String getSon(){
        return this.son;
    }

    public void sePresenter(){
        System.out.printf("Mon nom est %s, j'ai %d ans et je fais %s.",this.nom,this.age,this.son);
    }
}
class Chien extends Animal{

}
